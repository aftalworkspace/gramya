import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Home, 
  Trophy, 
  Award, 
  MessageSquare, 
  BarChart3, 
  Download, 
  Bell, 
  Menu,
  Settings as SettingsIcon,
  LogOut,
  ChevronLeft
} from 'lucide-react';
import { Screen, User } from './types';
import Splash from './screens/Splash';
import Login from './screens/Login';
import Dashboard from './screens/Dashboard';
import Quiz from './screens/Quiz';
import Achievements from './screens/Achievements';
import Leaderboard from './screens/Leaderboard';
import TeacherDashboard from './screens/TeacherDashboard';
import OfflineScreen from './screens/OfflineScreen';
import AITutor from './screens/AITutor';

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>('SPLASH');
  const [user, setUser] = useState<User | null>(null);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const navigate = (screen: Screen) => {
    setCurrentScreen(screen);
  };

  const handleLogin = (name: string, studentClass: string, language: 'English' | 'Tamil') => {
    setUser({
      name,
      class: studentClass,
      language,
      xp: 150,
      streak: 3,
      coins: 45,
      level: 2
    });
    navigate('DASHBOARD');
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'SPLASH': return <Splash onComplete={() => navigate('LOGIN')} />;
      case 'LOGIN': return <Login onLogin={handleLogin} />;
      case 'DASHBOARD': return <Dashboard user={user!} navigate={navigate} />;
      case 'QUIZ': return <Quiz onComplete={() => navigate('ACHIEVEMENTS')} onBack={() => navigate('DASHBOARD')} />;
      case 'ACHIEVEMENTS': return <Achievements navigate={navigate} />;
      case 'LEADERBOARD': return <Leaderboard navigate={navigate} />;
      case 'TEACHER': return <TeacherDashboard onBack={() => navigate('DASHBOARD')} />;
      case 'OFFLINE': return <OfflineScreen onBack={() => navigate('DASHBOARD')} />;
      case 'AI_TUTOR': return <AITutor onBack={() => navigate('DASHBOARD')} />;
      default: return <Dashboard user={user!} navigate={navigate} />;
    }
  };

  const showNavbar = !['SPLASH', 'LOGIN'].includes(currentScreen);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col max-w-md mx-auto relative overflow-hidden shadow-2xl">
      {/* Status Bar Mockup */}
      <div className="h-6 bg-white flex items-center justify-between px-4 text-[10px] font-medium text-slate-400">
        <span>9:41</span>
        <div className="flex items-center gap-1">
          {isOffline && <Download size={10} className="text-orange-500" />}
          <span>5G</span>
          <span>100%</span>
        </div>
      </div>

      <main className="flex-1 overflow-y-auto pb-20">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentScreen}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
            className="h-full"
          >
            {renderScreen()}
          </motion.div>
        </AnimatePresence>
      </main>

      {showNavbar && (
        <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white/80 backdrop-blur-lg border-t border-slate-100 px-6 py-3 flex justify-between items-center z-50">
          <NavButton active={currentScreen === 'DASHBOARD'} icon={<Home size={22} />} label="Home" onClick={() => navigate('DASHBOARD')} />
          <NavButton active={currentScreen === 'LEADERBOARD'} icon={<Trophy size={22} />} label="Rank" onClick={() => navigate('LEADERBOARD')} />
          <NavButton active={currentScreen === 'AI_TUTOR'} icon={<MessageSquare size={22} />} label="AI Guru" onClick={() => navigate('AI_TUTOR')} />
          <NavButton active={currentScreen === 'ACHIEVEMENTS'} icon={<Award size={22} />} label="Badges" onClick={() => navigate('ACHIEVEMENTS')} />
          <NavButton active={currentScreen === 'TEACHER'} icon={<BarChart3 size={22} />} label="Stats" onClick={() => navigate('TEACHER')} />
        </nav>
      )}

      {/* Offline Indicator Toast */}
      <AnimatePresence>
        {isOffline && (
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 50, opacity: 0 }}
            className="absolute bottom-24 left-4 right-4 bg-orange-500 text-white px-4 py-2 rounded-full text-xs font-medium flex items-center justify-center gap-2 shadow-lg z-50"
            onClick={() => navigate('OFFLINE')}
          >
            <Download size={14} />
            <span>Offline Mode: Lessons available locally</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

interface NavButtonProps {
  active: boolean;
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
}

const NavButton: React.FC<NavButtonProps> = ({ active, icon, label, onClick }) => (
  <button 
    onClick={onClick}
    className={`flex flex-col items-center gap-1 transition-colors ${active ? 'text-primary-500' : 'text-slate-400'}`}
  >
    <div className={`p-1 rounded-xl transition-all ${active ? 'bg-primary-50 ring-4 ring-primary-50' : ''}`}>
      {icon}
    </div>
    <span className="text-[10px] font-bold uppercase tracking-wider">{label}</span>
  </button>
);

export default App;
