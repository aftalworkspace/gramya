import React from 'react';
import { motion } from 'motion/react';
import { MOCK_LEADERBOARD } from '../data/mockData';
import { Trophy, Crown, ArrowUp, ChevronRight } from 'lucide-react';
import { Screen } from '../types';

interface LeaderboardProps {
  navigate: (screen: Screen) => void;
}

const Leaderboard: React.FC<LeaderboardProps> = ({ navigate }) => {
  return (
    <div className="p-6 space-y-8 bg-gradient-to-b from-primary-50 to-slate-50 min-h-full">
      {/* Header */}
      <h2 className="text-3xl flex items-center gap-3 mt-4 text-slate-800">
        <Trophy size={32} className="text-accent-yellow" />
        Leaderboard
      </h2>

      {/* Top 3 Podium */}
      <div className="flex items-end justify-center gap-4 pt-10 pb-6 relative">
        {/* 2nd Place */}
        <div className="flex flex-col items-center">
          <div className="relative mb-2">
            <div className="w-16 h-16 rounded-full border-4 border-slate-200 overflow-hidden shadow-lg bg-white">
              <img src={MOCK_LEADERBOARD[1].avatar} alt="" />
            </div>
            <div className="absolute -bottom-1 -right-1 bg-slate-300 text-white w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ring-2 ring-white">2</div>
          </div>
          <div className="w-20 h-24 bg-white/60 backdrop-blur-sm rounded-t-2xl shadow-xl border border-white flex flex-col items-center pt-4">
             <p className="text-[10px] font-bold text-slate-600 truncate w-full px-2 text-center">{MOCK_LEADERBOARD[1].name}</p>
             <p className="text-xs font-bold text-primary-600">{MOCK_LEADERBOARD[1].xp} XP</p>
          </div>
        </div>

        {/* 1st Place */}
        <div className="flex flex-col items-center -mt-10 scale-110 relative z-10">
          <div className="absolute -top-12 animate-bounce">
            <Crown size={32} className="text-accent-yellow fill-accent-yellow" />
          </div>
          <div className="relative mb-2">
            <div className="w-20 h-20 rounded-full border-4 border-accent-yellow overflow-hidden shadow-xl bg-white ring-4 ring-accent-yellow/20">
              <img src={MOCK_LEADERBOARD[0].avatar} alt="" />
            </div>
            <div className="absolute -bottom-1 -right-1 bg-accent-yellow text-white w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ring-2 ring-white">1</div>
          </div>
          <div className="w-24 h-32 bg-primary-600 rounded-t-2xl shadow-2xl flex flex-col items-center pt-4 text-white">
             <p className="text-xs font-bold truncate w-full px-2 text-center">{MOCK_LEADERBOARD[0].name}</p>
             <p className="text-sm font-bold text-primary-100">{MOCK_LEADERBOARD[0].xp} XP</p>
          </div>
        </div>

        {/* 3rd Place */}
        <div className="flex flex-col items-center">
          <div className="relative mb-2">
            <div className="w-16 h-16 rounded-full border-4 border-orange-200 overflow-hidden shadow-lg bg-white">
              <img src={MOCK_LEADERBOARD[2].avatar} alt="" />
            </div>
            <div className="absolute -bottom-1 -right-1 bg-orange-300 text-white w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ring-2 ring-white">3</div>
          </div>
          <div className="w-20 h-20 bg-white/60 backdrop-blur-sm rounded-t-2xl shadow-xl border border-white flex flex-col items-center pt-4">
             <p className="text-[10px] font-bold text-slate-600 truncate w-full px-2 text-center">{MOCK_LEADERBOARD[2].name}</p>
             <p className="text-xs font-bold text-primary-600">{MOCK_LEADERBOARD[2].xp} XP</p>
          </div>
        </div>
      </div>

      {/* Rankings List */}
      <div className="space-y-3">
        {MOCK_LEADERBOARD.slice(3).map((student, idx) => (
          <motion.div
            key={student.name}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="bg-white p-4 rounded-3xl soft-shadow border border-slate-100 flex items-center justify-between"
          >
            <div className="flex items-center gap-4">
              <span className="w-6 text-sm font-bold text-slate-400">{student.rank}</span>
              <div className="w-12 h-12 rounded-2xl overflow-hidden bg-slate-100 p-0.5 ring-2 ring-slate-50">
                <img src={student.avatar} alt="" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-800">{student.name}</h4>
                <div className="flex items-center gap-1">
                  <ArrowUp size={10} className="text-secondary-500" />
                  <span className="text-[10px] font-bold text-secondary-500 uppercase">Gaining fast</span>
                </div>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm font-display text-primary-600 font-bold">{student.xp} XP</p>
              <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest leading-none">Global Rank</p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* User Current Rank Bar */}
      <div className="bg-primary-900 text-white p-5 rounded-[32px] flex items-center justify-between shadow-xl mt-4">
        <div className="flex items-center gap-4">
          <span className="w-8 h-8 rounded-full bg-primary-800 flex items-center justify-center text-xs font-bold">12</span>
          <div className="w-10 h-10 rounded-xl overflow-hidden border border-primary-700 bg-primary-800">
             <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=You`} alt="" />
          </div>
          <div>
            <h4 className="text-sm font-bold">You (Student)</h4>
            <p className="text-[10px] text-primary-300">Top 15% this week</p>
          </div>
        </div>
        <ChevronRight size={20} className="text-primary-400" />
      </div>
    </div>
  );
};

export default Leaderboard;
