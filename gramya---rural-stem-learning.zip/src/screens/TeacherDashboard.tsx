import React from 'react';
import { motion } from 'motion/react';
import { 
  BarChart3, 
  Users, 
  Target, 
  AlertTriangle, 
  Search, 
  Filter,
  Download,
  ChevronLeft,
  MoreVertical
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell
} from 'recharts';

interface TeacherDashboardProps {
  onBack: () => void;
}

const data = [
  { name: 'Week 1', score: 65 },
  { name: 'Week 2', score: 78 },
  { name: 'Week 3', score: 72 },
  { name: 'Week 4', score: 85 },
];

const subjectData = [
  { name: 'Math', score: 85, color: '#3b82f6' },
  { name: 'Sci', score: 92, color: '#22c55e' },
  { name: 'Tech', score: 65, color: '#a855f7' },
  { name: 'Eng', score: 45, color: '#f97316' },
];

const TeacherDashboard: React.FC<TeacherDashboardProps> = ({ onBack }) => {
  return (
    <div className="p-6 space-y-8 bg-slate-50 min-h-full">
      {/* Header */}
      <div className="flex items-center justify-between mt-4">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-slate-400 soft-shadow">
            <ChevronLeft size={20} />
          </button>
          <h2 className="text-2xl">Teacher Insights</h2>
        </div>
        <div className="w-10 h-10 bg-primary-600 rounded-xl flex items-center justify-center text-white soft-shadow">
          <Download size={20} />
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white p-5 rounded-[32px] soft-shadow border border-slate-50">
          <div className="w-10 h-10 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 mb-4">
            <Users size={20} />
          </div>
          <p className="text-2xl font-display">42</p>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Total Students</p>
        </div>
        <div className="bg-white p-5 rounded-[32px] soft-shadow border border-slate-50 text-right">
          <div className="w-10 h-10 bg-secondary-50 rounded-2xl flex items-center justify-center text-secondary-500 mb-4 ml-auto">
            <Target size={20} />
          </div>
          <p className="text-2xl font-display text-secondary-500">78%</p>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Avg. Score</p>
        </div>
      </div>

      {/* Charts Section */}
      <div className="space-y-4">
        <h3 className="text-lg px-2">Performance Trend</h3>
        <div className="bg-white p-4 rounded-[32px] soft-shadow border border-slate-50 h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data}>
              <defs>
                <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <Tooltip 
                contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
              />
              <Area type="monotone" dataKey="score" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorScore)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Subject Performance */}
      <div className="space-y-4">
        <h3 className="text-lg px-2">Subject Mastery</h3>
        <div className="bg-white p-4 rounded-[32px] soft-shadow border border-slate-50 h-[250px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={subjectData}>
              <Bar dataKey="score" radius={[8, 8, 0, 0]}>
                {subjectData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 'bold' }} />
              <Tooltip cursor={{ fill: 'transparent' }} contentStyle={{ borderRadius: '16px', border: 'none' }} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Alerts / Interventions */}
      <div className="space-y-4">
        <div className="flex items-center justify-between px-2">
          <h3 className="text-lg">Critical Attention</h3>
          <span className="text-[10px] font-bold text-red-500 bg-red-50 px-2 py-0.5 rounded-full uppercase">3 Students</span>
        </div>
        <div className="space-y-3">
          {[
            { name: 'Kushal R.', issue: 'Inactive for 4 days', color: 'text-orange-500' },
            { name: 'Anita S.', issue: 'Low score in Circuits', color: 'text-red-500' }
          ].map((student, idx) => (
            <div key={idx} className="bg-white p-4 rounded-3xl soft-shadow border border-slate-50 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center text-slate-400">
                  <Users size={18} />
                </div>
                <div>
                  <h4 className="text-sm font-bold">{student.name}</h4>
                  <p className={`text-[10px] font-medium ${student.color}`}>{student.issue}</p>
                </div>
              </div>
              <button className="text-slate-400">
                <MoreVertical size={18} />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TeacherDashboard;
