import React from 'react';
import { motion } from 'motion/react';
import { 
  Download, 
  CloudOff, 
  RefreshCw, 
  BookOpen, 
  MoreVertical,
  CheckCircle2,
  PlayCircle,
  ChevronLeft
} from 'lucide-react';

interface OfflineScreenProps {
  onBack: () => void;
}

const OFFLINE_LESSONS = [
  { id: '1', title: 'Life of a Plant', size: '12MB', subject: 'Science', completed: true },
  { id: '2', title: 'Numbers & Fractions', size: '8MB', subject: 'Mathematics', completed: false },
  { id: '3', title: 'How Planes Fly', size: '24MB', subject: 'Engineering', completed: false },
];

const OfflineScreen: React.FC<OfflineScreenProps> = ({ onBack }) => {
  return (
    <div className="p-6 space-y-8 bg-slate-50 min-h-full">
      <div className="flex items-center justify-between mt-4">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-slate-400 soft-shadow">
            <ChevronLeft size={20} />
          </button>
          <h2 className="text-2xl">Offline Study</h2>
        </div>
        <div className="w-10 h-10 bg-orange-100 rounded-xl flex items-center justify-center text-orange-600 soft-shadow">
          <CloudOff size={20} />
        </div>
      </div>

      <div className="bg-orange-500 rounded-[32px] p-6 text-white shadow-xl soft-shadow relative overflow-hidden">
        <div className="relative z-10 flex items-center justify-between">
          <div className="flex-1">
            <h3 className="text-xl mb-1 text-white">Local Mode Active</h3>
            <p className="text-orange-100 text-xs font-bold uppercase tracking-widest leading-normal">
              You have 3 lessons saved for offline learning.
            </p>
          </div>
          <button className="bg-white/20 backdrop-blur-md p-3 rounded-2xl border border-white/20 active:rotate-180 transition-transform duration-500">
            <RefreshCw size={24} />
          </button>
        </div>
        <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-white/10 rounded-full blur-xl" />
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between px-2">
          <h3 className="text-lg">Saved Lessons</h3>
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">3 Items • 44MB</span>
        </div>

        <div className="space-y-4">
          {OFFLINE_LESSONS.map((lesson, idx) => (
            <motion.div
              key={lesson.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white p-5 rounded-[32px] soft-shadow border border-slate-100 group"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-2xl ${lesson.completed ? 'bg-secondary-50 text-secondary-500' : 'bg-primary-50 text-primary-500'}`}>
                  <BookOpen size={20} />
                </div>
                <button className="text-slate-300">
                  <MoreVertical size={18} />
                </button>
              </div>
              <h4 className="text-lg mb-1 leading-tight">{lesson.title}</h4>
              <div className="flex items-center justify-between">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{lesson.subject} • {lesson.size}</p>
                {lesson.completed ? (
                  <div className="flex items-center gap-1 text-secondary-500">
                    <CheckCircle2 size={14} />
                    <span className="text-[10px] font-bold uppercase tracking-widest">Done</span>
                  </div>
                ) : (
                  <button className="flex items-center gap-1.5 text-primary-600 bg-primary-50 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest hover:bg-primary-100 transition-colors">
                    <PlayCircle size={14} />
                    Play
                  </button>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default OfflineScreen;
