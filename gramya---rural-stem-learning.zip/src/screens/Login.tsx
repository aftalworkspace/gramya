import React, { useState } from 'react';
import { motion } from 'motion/react';
import { User, BookOpen, Globe } from 'lucide-react';

interface LoginProps {
  onLogin: (name: string, studentClass: string, language: 'English' | 'Tamil') => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [name, setName] = useState('');
  const [studentClass, setStudentClass] = useState('6');
  const [language, setLanguage] = useState<'English' | 'Tamil'>('English');

  return (
    <div className="h-full p-8 flex flex-col justify-center bg-white">
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-10 text-center"
      >
        <div className="w-20 h-20 bg-primary-100 rounded-3xl flex items-center justify-center mx-auto mb-4 text-primary-600">
          <BookOpen size={40} />
        </div>
        <h2 className="text-3xl mb-1">Welcome Student!</h2>
        <p className="text-slate-500 font-medium">Let's set up your learning path</p>
      </motion.div>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-2">
            <User size={16} /> What's your name?
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter your name"
            className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl px-5 py-4 focus:ring-4 focus:ring-primary-50 focus:border-primary-500 transition-all outline-none font-medium"
          />
        </div>

        <div>
          <label className="block text-sm font-bold text-slate-700 mb-2">Which class are you in?</label>
          <div className="grid grid-cols-4 gap-3">
            {['6', '7', '8', '9', '10', '11', '12'].map((c) => (
              <button
                key={c}
                onClick={() => setStudentClass(c)}
                className={`py-3 rounded-2xl font-bold transition-all border-2 ${
                  studentClass === c 
                  ? 'bg-primary-500 border-primary-500 text-white shadow-lg shadow-primary-200' 
                  : 'bg-white border-slate-100 text-slate-400 hover:border-slate-200'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-2">
            <Globe size={16} /> Choose Language
          </label>
          <div className="flex gap-4">
            <button
              onClick={() => setLanguage('English')}
              className={`flex-1 py-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all border-2 ${
                language === 'English'
                ? 'bg-secondary-500 border-secondary-500 text-white shadow-lg shadow-secondary-100'
                : 'bg-white border-slate-100 text-slate-400'
              }`}
            >
              English
            </button>
            <button
              onClick={() => setLanguage('Tamil')}
              className={`flex-1 py-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all border-2 ${
                language === 'Tamil'
                ? 'bg-secondary-500 border-secondary-500 text-white shadow-lg shadow-secondary-100'
                : 'bg-white border-slate-100 text-slate-400'
              }`}
            >
              தமிழ் (Tamil)
            </button>
          </div>
        </div>

        <button
          onClick={() => name && onLogin(name, studentClass, language)}
          disabled={!name}
          className={`w-full py-5 rounded-3xl font-bold text-lg shadow-xl transition-all flex items-center justify-center gap-2 ${
            name 
            ? 'bg-primary-600 text-white hover:bg-primary-700 active:scale-95' 
            : 'bg-slate-100 text-slate-300 cursor-not-allowed'
          }`}
        >
          Let's Go!
        </button>
      </div>

      <div className="mt-auto text-center pt-10">
        <p className="text-slate-400 text-xs">
          Already have an account? <span className="text-primary-600 font-bold">Login here</span>
        </p>
      </div>
    </div>
  );
};

export default Login;
