import React from 'react';
import { motion } from 'motion/react';
import { User, Subject as ISubject, Screen } from '../types';
import { SUBJECTS } from '../data/mockData';
import { 
  Flame, 
  Coins, 
  Star, 
  ChevronRight, 
  Play, 
  Calculator, 
  Atom, 
  Cpu, 
  Settings as SettingsIcon,
  Search
} from 'lucide-react';

interface DashboardProps {
  user: User;
  navigate: (screen: Screen) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, navigate }) => {
  const getIcon = (iconName: string, size: number = 24) => {
    switch (iconName) {
      case 'Calculator': return <Calculator size={size} />;
      case 'Atom': return <Atom size={size} />;
      case 'Cpu': return <Cpu size={size} />;
      case 'Settings': return <SettingsIcon size={size} />;
      default: return <Calculator size={size} />;
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-primary-100 rounded-2xl flex items-center justify-center border-2 border-primary-200">
            <img 
              src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${user.name}`} 
              alt="Avatar" 
              className="w-10 h-10"
            />
          </div>
          <div>
            <h3 className="text-xl">Hi, {user.name}!</h3>
            <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Class {user.class} Student</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button className="p-2 bg-white rounded-xl text-slate-400 soft-shadow">
            <Search size={20} />
          </button>
          <button className="p-2 bg-white rounded-xl text-slate-400 soft-shadow">
            <SettingsIcon size={20} />
          </button>
        </div>
      </div>

      {/* Hero Stats Card */}
      <div className="relative overflow-hidden bg-primary-600 rounded-[32px] p-6 text-white shadow-xl soft-shadow">
        <div className="relative z-10">
          <div className="flex justify-between items-start mb-6">
            <div>
              <p className="text-primary-100 text-xs font-bold uppercase tracking-widest mb-1">Current Level</p>
              <h1 className="text-4xl font-display">Level {user.level}</h1>
            </div>
            <div className="bg-white/20 backdrop-blur-md rounded-2xl px-3 py-1 flex items-center gap-1.5 border border-white/20">
              <Star size={14} className="text-accent-yellow fill-accent-yellow" />
              <span className="text-sm font-bold">{user.xp} XP</span>
            </div>
          </div>
          
          <div className="space-y-2 mb-6">
            <div className="flex justify-between text-xs font-bold uppercase tracking-wider">
              <span>Progress to Lv. {user.level + 1}</span>
              <span>75%</span>
            </div>
            <div className="h-3 bg-white/20 rounded-full overflow-hidden border border-white/10 p-0.5">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: '75%' }}
                className="h-full bg-white rounded-full shadow-[0_0_10px_rgba(255,255,255,0.5)]"
              />
            </div>
          </div>

          <div className="flex gap-4">
            <div className="flex-1 bg-white/10 backdrop-blur-sm rounded-2xl p-3 border border-white/10">
              <div className="flex items-center gap-2 mb-1">
                <div className="bg-orange-500/30 p-1.5 rounded-lg">
                  <Flame size={16} className="text-orange-400 fill-orange-400" />
                </div>
                <span className="text-xs font-bold text-primary-100 italic">Day Streak</span>
              </div>
              <p className="text-xl font-display">{user.streak} Days</p>
            </div>
            <div className="flex-1 bg-white/10 backdrop-blur-sm rounded-2xl p-3 border border-white/10">
              <div className="flex items-center gap-2 mb-1">
                <div className="bg-accent-yellow/30 p-1.5 rounded-lg">
                  <Coins size={16} className="text-accent-yellow" />
                </div>
                <span className="text-xs font-bold text-primary-100 italic">Learner Coins</span>
              </div>
              <p className="text-xl font-display">{user.coins}</p>
            </div>
          </div>
        </div>
        
        {/* Background Decorative Circles */}
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-2xl" />
        <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-accent-yellow/10 rounded-full blur-2xl" />
      </div>

      {/* Continue Learning */}
      <div className="bg-secondary-50 p-4 rounded-3xl border-2 border-secondary-500/10 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-secondary-500 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-secondary-100">
            <Play size={24} fill="currentColor" />
          </div>
          <div>
            <p className="text-xs font-bold text-secondary-500 uppercase tracking-widest">Next Lesson</p>
            <h4 className="text-sm">Solar Energy Basics</h4>
          </div>
        </div>
        <button 
          onClick={() => navigate('QUIZ')}
          className="bg-secondary-500 text-white px-4 py-2 rounded-xl font-bold text-xs flex items-center gap-1 active:scale-95 transition-transform"
        >
          Resume
        </button>
      </div>

      {/* Subjects Header */}
      <div className="flex items-center justify-between pt-2">
        <h3 className="text-xl">Subjects</h3>
        <button className="text-primary-600 text-sm font-bold flex items-center gap-1">
          See All <ChevronRight size={16} />
        </button>
      </div>

      {/* Subject Grid */}
      <div className="grid grid-cols-2 gap-4">
        {SUBJECTS.map((subject, idx) => (
          <motion.div
            key={subject.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.1 * idx }}
            whileTap={{ scale: 0.98 }}
            className="bg-white p-4 rounded-[32px] soft-shadow border border-slate-50 relative overflow-hidden group cursor-pointer"
            onClick={() => navigate('QUIZ')}
          >
            <div className={`w-12 h-12 ${subject.color} rounded-2xl flex items-center justify-center text-white mb-4 shadow-lg`}>
              {getIcon(subject.icon)}
            </div>
            <h4 className="text-lg leading-tight mb-2">{subject.name}</h4>
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{subject.lessons} Lessons</span>
              <span className="text-[10px] font-bold text-primary-600 bg-primary-50 px-2 py-0.5 rounded-full">{subject.progress}%</span>
            </div>
            <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${subject.progress}%` }}
                className={`h-full ${subject.color} rounded-full`}
              />
            </div>
            
            {/* Subtle background decoration */}
            <div className="absolute -bottom-2 -right-2 opacity-[0.03] group-hover:opacity-[0.08] transition-opacity">
              {getIcon(subject.icon, 64)}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
