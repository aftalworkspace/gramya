import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, Rocket } from 'lucide-react';

interface SplashProps {
  onComplete: () => void;
}

const Splash: React.FC<SplashProps> = ({ onComplete }) => {
  return (
    <div className="h-full bg-gradient-to-br from-primary-600 to-primary-500 flex flex-col items-center justify-center text-white p-8 relative overflow-hidden">
      {/* Animated background elements */}
      <motion.div 
        animate={{ 
          scale: [1, 1.2, 1],
          rotate: [0, 90, 180, 270, 360],
        }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        className="absolute -top-20 -left-20 w-64 h-64 bg-white/10 rounded-full blur-3xl"
      />
      <motion.div 
        animate={{ 
          scale: [1.2, 1, 1.2],
        }}
        transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }}
        className="absolute -bottom-20 -right-20 w-80 h-80 bg-accent-yellow/20 rounded-full blur-3xl"
      />

      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 260, damping: 20 }}
        className="mb-8 relative"
      >
        <div className="w-40 h-40 bg-white rounded-[40px] flex items-center justify-center shadow-2xl relative z-10">
          <Rocket className="w-20 h-20 text-primary-500" />
        </div>
        <motion.div 
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute -top-4 -right-4 bg-accent-yellow p-3 rounded-2xl shadow-lg z-20"
        >
          <Sparkles className="w-6 h-6 text-primary-600" />
        </motion.div>
      </motion.div>

      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="text-center mb-12"
      >
        <h1 className="text-4xl font-display mb-2">Gramya</h1>
        <p className="text-primary-100 font-medium">STEM Learning for Rural India</p>
      </motion.div>

      <motion.button
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.6 }}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={onComplete}
        className="bg-white text-primary-600 px-10 py-4 rounded-3xl font-bold text-lg shadow-xl flex items-center gap-3"
      >
        Start Learning
        <motion.span
          animate={{ x: [0, 5, 0] }}
          transition={{ duration: 1, repeat: Infinity }}
        >
          →
        </motion.span>
      </motion.button>

      <div className="absolute bottom-8 text-primary-200 text-xs font-medium uppercase tracking-widest opacity-60">
        Proudly Made for Rural Schools
      </div>
    </div>
  );
};

export default Splash;
