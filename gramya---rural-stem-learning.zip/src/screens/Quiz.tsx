import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ChevronLeft, 
  Timer, 
  HelpCircle, 
  CheckCircle2, 
  XCircle,
  Star,
  Coins,
  ChevronRight
} from 'lucide-react';

interface QuizProps {
  onComplete: () => void;
  onBack: () => void;
}

const Quiz: React.FC<QuizProps> = ({ onComplete, onBack }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [timeLeft, setTimeLeft] = useState(30);
  const [showResultPopup, setShowResultPopup] = useState(false);

  const questions = [
    {
      text: "Which of these is a clean source of energy?",
      options: ["Coal", "Solar Wind", "Petrol", "Natural Gas"],
      correct: 1,
      explanation: "Solar and wind energy are natural resources that don't pollute our earth!"
    }
  ];

  useEffect(() => {
    if (timeLeft > 0 && !showFeedback) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [timeLeft, showFeedback]);

  const handleOptionSelect = (idx: number) => {
    if (showFeedback) return;
    setSelectedOption(idx);
    const correct = idx === questions[currentQuestion].correct;
    setIsCorrect(correct);
    setShowFeedback(true);
    
    if (correct) {
      setTimeout(() => setShowResultPopup(true), 1500);
    }
  };

  return (
    <div className="h-full bg-slate-50 flex flex-col">
      {/* Header */}
      <div className="p-6 flex items-center justify-between">
        <button onClick={onBack} className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-slate-400 soft-shadow">
          <ChevronLeft size={20} />
        </button>
        <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-2xl soft-shadow">
          <Timer size={18} className={timeLeft < 10 ? 'text-red-500 animate-pulse' : 'text-primary-600'} />
          <span className={`text-sm font-bold ${timeLeft < 10 ? 'text-red-500' : 'text-slate-600'}`}>00:{timeLeft < 10 ? `0${timeLeft}` : timeLeft}</span>
        </div>
        <div className="w-10" /> {/* Spacer */}
      </div>

      <div className="px-6 flex-1">
        {/* Progress */}
        <div className="flex items-center gap-3 mb-8">
          <div className="flex-1 h-3 bg-slate-200 rounded-full overflow-hidden p-0.5">
            <div className="h-full bg-primary-500 rounded-full w-1/3" />
          </div>
          <span className="text-xs font-bold text-slate-400">Quest 1/3</span>
        </div>

        {/* Question Card */}
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="bg-white rounded-[32px] p-8 soft-shadow border border-slate-100 mb-8 relative"
        >
          <div className="w-12 h-12 bg-primary-50 rounded-2xl flex items-center justify-center text-primary-600 mb-6">
            <HelpCircle size={28} />
          </div>
          <h2 className="text-2xl leading-tight text-slate-800">
            {questions[currentQuestion].text}
          </h2>
          
          <div className="absolute -top-4 -right-4 bg-accent-yellow p-3 rounded-2xl shadow-lg rotate-12">
            <Star size={24} className="text-primary-600 fill-primary-600" />
          </div>
        </motion.div>

        {/* Options */}
        <div className="space-y-4">
          {questions[currentQuestion].options.map((option, idx) => (
            <motion.button
              key={option}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleOptionSelect(idx)}
              disabled={showFeedback}
              className={`w-full p-5 rounded-3xl font-bold flex items-center justify-between border-2 transition-all ${
                showFeedback 
                  ? idx === questions[currentQuestion].correct
                    ? 'bg-secondary-50 border-secondary-500 text-secondary-600'
                    : idx === selectedOption
                      ? 'bg-red-50 border-red-500 text-red-600'
                      : 'bg-white border-slate-100 text-slate-300'
                  : selectedOption === idx
                    ? 'bg-primary-50 border-primary-500 text-primary-600'
                    : 'bg-white border-slate-100 text-slate-700 hover:border-slate-200'
              }`}
            >
              <div className="flex items-center gap-4">
                <span className={`w-8 h-8 rounded-xl flex items-center justify-center text-sm ${
                  showFeedback && idx === questions[currentQuestion].correct
                  ? 'bg-secondary-500 text-white'
                  : 'bg-slate-100 text-slate-400'
                }`}>
                  {String.fromCharCode(65 + idx)}
                </span>
                {option}
              </div>
              {showFeedback && idx === questions[currentQuestion].correct && (
                <CheckCircle2 size={24} />
              )}
              {showFeedback && idx === selectedOption && idx !== questions[currentQuestion].correct && (
                <XCircle size={24} />
              )}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Success Popup */}
      <AnimatePresence>
        {showResultPopup && (
          <div className="absolute inset-0 z-[100] flex items-center justify-center p-8">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-primary-600/20 backdrop-blur-sm"
              onClick={() => setShowResultPopup(false)}
            />
            <motion.div
              initial={{ scale: 0.5, y: 50, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.5, y: 50, opacity: 0 }}
              className="bg-white rounded-[40px] p-8 w-full shadow-2xl relative z-10 text-center"
            >
              <motion.div 
                animate={{ rotate: [0, 10, -10, 0], scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="w-24 h-24 bg-accent-yellow rounded-full flex items-center justify-center mx-auto mb-6 text-white text-4xl shadow-lg shadow-accent-yellow/20"
              >
                🏆
              </motion.div>
              <h2 className="text-3xl mb-2 text-slate-800">Knowledge Unlocked!</h2>
              <p className="text-slate-500 mb-8 font-medium">Excellent work! You've mastered the concept of Renewable Energy.</p>
              
              <div className="flex gap-4 mb-8">
                <div className="flex-1 bg-primary-50 p-4 rounded-3xl border border-primary-100">
                  <div className="flex items-center justify-center gap-1.5 text-primary-600 mb-1">
                    <Star size={16} fill="currentColor" />
                    <span className="text-[10px] font-bold uppercase tracking-wider">XP Gained</span>
                  </div>
                  <p className="text-2xl font-display text-primary-700">+25</p>
                </div>
                <div className="flex-1 bg-accent-yellow/10 p-4 rounded-3xl border border-accent-yellow/20">
                  <div className="flex items-center justify-center gap-1.5 text-orange-600 mb-1">
                    <Coins size={16} fill="currentColor" />
                    <span className="text-[10px] font-bold uppercase tracking-wider">Coins</span>
                  </div>
                  <p className="text-2xl font-display text-orange-700">+10</p>
                </div>
              </div>

              <button
                onClick={onComplete}
                className="w-full bg-primary-600 text-white py-5 rounded-3xl font-bold text-lg shadow-xl flex items-center justify-center gap-2 group"
              >
                Claim Rewards
                <ChevronRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Quiz;
