import React from 'react';
import { motion } from 'motion/react';
import { BADGES } from '../data/mockData';
import { 
  Award, 
  Lock, 
  CheckCircle2, 
  ChevronRight, 
  Star,
  Coins,
  TrendingUp,
  ShieldAlert
} from 'lucide-react';
import { Screen } from '../types';

interface AchievementsProps {
  navigate: (screen: Screen) => void;
}

const Achievements: React.FC<AchievementsProps> = ({ navigate }) => {
  return (
    <div className="p-6 space-y-8">
      {/* Header */}
      <h2 className="text-3xl flex items-center gap-3 mt-4">
        <Award size={32} className="text-accent-yellow" />
        Achievements
      </h2>

      {/* Level Summary */}
      <div className="bg-white rounded-[32px] p-6 soft-shadow border border-slate-50">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 bg-primary-500 rounded-2xl flex items-center justify-center text-white text-2xl font-display shadow-lg shadow-primary-100">
              2
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-0.5">Explorer Rank</p>
              <h3 className="text-xl">Level 2 Path</h3>
            </div>
          </div>
          <div className="text-right">
            <p className="text-2xl font-display text-primary-600">840</p>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Total XP</p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100 text-center">
            <Coins size={20} className="text-accent-yellow mx-auto mb-1" />
            <p className="text-sm font-bold">120</p>
            <p className="text-[8px] font-bold text-slate-400 uppercase">Coins</p>
          </div>
          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100 text-center">
            <Star size={20} className="text-primary-500 mx-auto mb-1" />
            <p className="text-sm font-bold">12</p>
            <p className="text-[8px] font-bold text-slate-400 uppercase">Quizzes</p>
          </div>
          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100 text-center">
            <TrendingUp size={20} className="text-secondary-500 mx-auto mb-1" />
            <p className="text-sm font-bold">3</p>
            <p className="text-[8px] font-bold text-slate-400 uppercase">Courses</p>
          </div>
        </div>
      </div>

      {/* Badges Collection */}
      <div className="space-y-4">
        <div className="flex items-center justify-between px-2">
          <h4 className="text-lg">Badges Unlocked</h4>
          <span className="text-sm font-medium text-primary-600 bg-primary-50 px-3 py-1 rounded-full">2/8 Unlocked</span>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {BADGES.map((badge, idx) => (
            <motion.div
              key={badge.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.1 }}
              className={`p-5 rounded-[32px] soft-shadow border text-center relative overflow-hidden transition-all ${
                badge.unlocked 
                ? 'bg-white border-primary-100' 
                : 'bg-slate-50 border-slate-100 opacity-80'
              }`}
            >
              <div className={`w-16 h-16 mx-auto mb-4 rounded-3xl flex items-center justify-center text-3xl shadow-lg ${
                badge.unlocked ? 'bg-primary-50' : 'bg-slate-200 grayscale'
              }`}>
                {badge.icon === 'Rocket' && '🚀'}
                {badge.icon === 'Zap' && '⚡'}
                {badge.icon === 'Flame' && '🔥'}
                {badge.icon === 'Shield' && '🛡️'}
              </div>
              <h5 className={`text-sm font-bold mb-1 ${badge.unlocked ? 'text-slate-800' : 'text-slate-400'}`}>
                {badge.name}
              </h5>
              <p className="text-[10px] text-slate-400 leading-tight">
                {badge.description}
              </p>

              {!badge.unlocked && (
                <div className="absolute top-2 right-2 bg-slate-100 p-1 rounded-lg text-slate-400">
                  <Lock size={12} />
                </div>
              )}
              {badge.unlocked && (
                <div className="absolute top-2 right-2 bg-primary-500 p-1 rounded-lg text-white">
                  <CheckCircle2 size={12} />
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </div>

      <button className="w-full py-4 rounded-2xl bg-white border-2 border-slate-100 text-slate-500 font-bold flex items-center justify-center gap-2 soft-shadow active:scale-95 transition-transform">
        View Gallery <ChevronRight size={18} />
      </button>
    </div>
  );
};

export default Achievements;
