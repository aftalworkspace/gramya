import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ChevronLeft, 
  Send, 
  Mic, 
  Sparkles, 
  User, 
  Bot,
  Brain
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface AITutorProps {
  onBack: () => void;
}

const AITutor: React.FC<AITutorProps> = ({ onBack }) => {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: 'Namaste! I am your AI STEM Guru. How can I help you today? You can ask me about Physics, Math, or even how things work in your village!' }
  ]);
  const [input, setInput] = useState('');

  const handleSend = () => {
    if (!input.trim()) return;
    const newMessages = [...messages, { role: 'user', content: input }];
    setMessages(newMessages);
    setInput('');
    
    // Simulate AI response
    setTimeout(() => {
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: `That's a great question about **${input}**! In STEM, we look at this by observing natural patterns. For example, did you know that the same math used in architecture is also found in a honeycomb?` 
      }]);
    }, 1000);
  };

  return (
    <div className="h-full bg-white flex flex-col">
      {/* Header */}
      <div className="p-6 bg-primary-600 text-white rounded-b-[40px] shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex items-center gap-4">
          <button onClick={onBack} className="p-2 bg-white/20 rounded-xl">
            <ChevronLeft size={20} />
          </button>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-primary-600 shadow-inner">
              <Bot size={28} />
            </div>
            <div>
              <h3 className="text-xl">AI Guru</h3>
              <div className="flex items-center gap-1">
                <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
                <span className="text-[10px] font-bold text-primary-100 uppercase tracking-widest">Knowledge Assistant</span>
              </div>
            </div>
          </div>
        </div>
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-2xl" />
      </div>

      {/* Chat Area */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.map((m, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div className={`max-w-[85%] p-4 rounded-3xl ${
              m.role === 'user' 
              ? 'bg-primary-500 text-white rounded-tr-none' 
              : 'bg-slate-50 text-slate-700 rounded-tl-none border border-slate-100'
            }`}>
              <div className="prose prose-sm prose-slate max-w-none">
                 <ReactMarkdown>{m.content}</ReactMarkdown>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Suggestions */}
      <div className="px-6 pb-2">
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
          {['How birds fly?', 'What is Gravity?', 'Solar Energy explained'].map((s) => (
            <button 
              key={s}
              onClick={() => setInput(s)}
              className="whitespace-nowrap px-4 py-2 bg-primary-50 text-primary-600 rounded-full text-[10px] font-bold uppercase tracking-wider border border-primary-100"
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Input Area */}
      <div className="p-6 bg-white border-t border-slate-100 flex items-center gap-3">
        <div className="flex-1 relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask me anything..."
            className="w-full bg-slate-100 border-none rounded-2xl px-5 py-4 focus:ring-4 focus:ring-primary-50 transition-all outline-none font-medium pr-12"
          />
          <button className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400">
            <Mic size={20} />
          </button>
        </div>
        <button 
          onClick={handleSend}
          className="w-12 h-12 bg-primary-600 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-primary-200 active:scale-90 transition-transform"
        >
          <Send size={20} />
        </button>
      </div>
    </div>
  );
};

export default AITutor;
