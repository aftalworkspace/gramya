import { Subject, Badge } from '../types';

export const SUBJECTS: Subject[] = [
  { id: 'math', name: 'Mathematics', icon: 'Calculator', color: 'bg-blue-500', progress: 65, lessons: 24 },
  { id: 'science', name: 'Science', icon: 'Atom', color: 'bg-green-500', progress: 40, lessons: 18 },
  { id: 'tech', name: 'Technology', icon: 'Cpu', color: 'bg-purple-500', progress: 10, lessons: 12 },
  { id: 'eng', name: 'Engineering', icon: 'Settings', color: 'bg-orange-500', progress: 0, lessons: 15 },
];

export const BADGES: Badge[] = [
  { id: '1', name: 'First Steps', description: 'Complete your first lesson', icon: 'Rocket', unlocked: true },
  { id: '2', name: 'Math Wizard', description: 'Get 100% in a math quiz', icon: 'Zap', unlocked: true },
  { id: '3', name: 'Streak 7', description: 'Maintain a 7-day streak', icon: 'Flame', unlocked: false },
  { id: '4', name: 'Science Hero', description: 'Complete all science modules', icon: 'Shield', unlocked: false },
];

export const MOCK_LEADERBOARD = [
  { name: 'Arjun S.', xp: 2450, rank: 1, avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Arjun' },
  { name: 'Priya K.', xp: 2320, rank: 2, avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Priya' },
  { name: 'Rahul M.', xp: 2100, rank: 3, avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Rahul' },
  { name: 'Deepa T.', xp: 1950, rank: 4, avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Deepa' },
  { name: 'Karthik V.', xp: 1800, rank: 5, avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Karthik' },
];
