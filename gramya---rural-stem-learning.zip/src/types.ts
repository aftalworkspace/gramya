export type Screen = 
  | 'SPLASH' 
  | 'LOGIN' 
  | 'DASHBOARD' 
  | 'QUIZ' 
  | 'ACHIEVEMENTS' 
  | 'LEADERBOARD' 
  | 'TEACHER' 
  | 'OFFLINE' 
  | 'AI_TUTOR';

export interface User {
  name: string;
  class: string;
  language: 'English' | 'Tamil';
  xp: number;
  streak: number;
  coins: number;
  level: number;
}

export interface Subject {
  id: string;
  name: string;
  icon: string;
  color: string;
  progress: number;
  lessons: number;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
}
